"""Domain model helpers and adapters."""
