"""Core calculus utilities (RD 2229 methods)."""
