"""Input/output helpers for file operations and serialization."""
