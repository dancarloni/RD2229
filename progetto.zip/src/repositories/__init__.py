"""Repository abstractions for persistence of materials/sections."""
