"""Utility helpers used across the project."""
