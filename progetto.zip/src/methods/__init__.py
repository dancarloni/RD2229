"""Verification methods implementations (SLU, SLE, TA)."""
