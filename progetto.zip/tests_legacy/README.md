Tests legacy
===========

Questa cartella contiene i test considerati obsoleti e non più eseguiti nel CI.
Sono stati spostati qui per preservare la storia, ma non vengono eseguiti da `pytest`.

Se fosse necessario ripristinarli per investigazioni, usare `git mv` per riportarli in `tests/`.

Nota: non cercare di correggere i test legacy in questo ramo; verranno riscritti o sostituiti in PR dedicate.
