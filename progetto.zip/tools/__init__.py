"""Utility tools per il progetto RD2229.

Contiene script e helper non legati direttamente ai moduli di calcolo,
ma utili per la gestione del repository (es. sincronizzazione verifications).
"""

__all__ = []
