"""Modelli delle sezioni."""
