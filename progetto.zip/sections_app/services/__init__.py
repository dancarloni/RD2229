"""Servizi di calcolo e persistenza."""
