"""Applicazione Tkinter per il calcolo delle proprietà geometriche delle sezioni."""
