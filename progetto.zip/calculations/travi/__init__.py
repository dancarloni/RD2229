"""Travi: moduli per flessione, taglio, torsione."""
