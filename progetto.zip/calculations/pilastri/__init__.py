"""Pilastri: moduli per compressione e pressoflessione."""
