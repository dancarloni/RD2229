"""Moduli per le scale.

Questo package contiene funzioni e procedure storiche per il calcolo
di scale (gradinate, rampe, pianerottoli) secondo le convenzioni
del progetto RD2229.

Al momento è uno stub: aggiungeremo moduli specifici in futuro.
"""

__all__ = []
