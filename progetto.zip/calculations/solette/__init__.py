"""Solette: moduli per piastre e solette."""
