# RD2229 Documentation

Welcome to the RD2229 documentation.

- Run: see CONTRIBUTING.md
- Tests: see tests/ and golden datasets in `src/repositories/data`
