# Formulas & References

This page will contain the formulas used by the project, alongside bibliographic
references and traceability to original sources (RD 2229/39, Santarella, Giangreco).

Placeholders are present where a citation is required: `cite-source`.
