# Changelog

All notable changes to this project will be documented in this file.

## Unreleased
- Quality & architecture overhaul: refactor into `src/` layout, add typing, tests, docs, and CI improvements.
