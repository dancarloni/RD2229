"""Verifiche correlate alle `calculations.scale`.

Questo package è mantenuto in sincronia con `src/rd2229/calculations/scale`:
per ogni modulo di calcolo verrà creato qui un corrispondente modulo di verifica.
"""

__all__ = []
