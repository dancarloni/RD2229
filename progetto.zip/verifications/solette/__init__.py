"""Verifiche correlate alle `calculations.solette`.

Per ogni modulo in `src/rd2229/calculations/solette` dovrà esistere
un corrispondente modulo di verifica in questo package.
"""

__all__ = []
