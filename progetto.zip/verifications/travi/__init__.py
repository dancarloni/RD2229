"""Verifiche correlate alle `calculations.travi`.

Per ogni modulo in `src/rd2229/calculations/travi` dovrà esistere
un corrispondente modulo di verifica in questo package.
"""

__all__ = []
