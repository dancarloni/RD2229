"""Verifiche correlate alle `calculations.pilastri`.

Per ogni modulo in `src/rd2229/calculations/pilastri` dovrà esistere
un corrispondente modulo di verifica in questo package.
"""

__all__ = []
