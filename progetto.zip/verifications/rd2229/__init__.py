"""Verifiche secondo RD2229: tensioni ammissibili, deformazioni, fessurazione."""
